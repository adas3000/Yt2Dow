package com.yt.androidytdownload.enum

enum class Kind {
    MP3,
    MP4;
}