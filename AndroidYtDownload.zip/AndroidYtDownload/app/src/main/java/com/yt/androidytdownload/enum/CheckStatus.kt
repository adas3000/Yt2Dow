package com.yt.androidytdownload.enum

enum class CheckStatus {
    Ok,
    Error,
    Checking}