package com.yt.androidytdownload.enum

enum class SocketResult {
    SUCCESS,
    FAILURE
}