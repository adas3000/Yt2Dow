package com.yt.androidytdownload.util

enum class SocketPort {
    Port(5005);

    public val port:Int

    constructor(port:Int){
        this.port = port
    }



}